
# A/B Testing Analyses: Fast Food Marketing & Mobile Game Retention

This repository contains two independent data analysis projects focused on A/B testing in different industries: one for evaluating marketing campaigns in a fast-food chain, and another for improving player retention in a mobile game.

---

## Project Overview

### 1. Fast Food Marketing Campaign Analysis
Evaluates the effectiveness of three distinct promotional strategies used to launch a new menu item. A/B testing was conducted over a four-week period.

### 2. Cookie Cats Game Improvement Test
Analyzes whether moving a progression gate from level 30 to 40 in a mobile game affects player retention over 1 and 7 days.

---

## Objectives

### Fast Food Campaign
- Identify which of the three marketing campaigns (Promotion 1, 2, or 3) leads to the highest weekly sales.

### Cookie Cats Game
- Measure how gate placement affects:
  - **1-Day Retention**
  - **7-Day Retention**

---

## Dataset Descriptions

### Fast Food Marketing Campaign
- **File**: `WA_Marketing-Campaign.csv`
- **548 rows × 8 columns**
- **Key columns**:
  - `MarketID`: Unique identifier for each market
  - `MarketSize`: Categorical (Small, Medium, Large)
  - `LocationID`: Store identifier
  - `AgeOfStore`: Age in years
  - `Promotion`: Campaign type (1, 2, or 3)
  - `week`: Week number (1-4)
  - `SalesInThousands`: Weekly sales in thousands

### Cookie Cats Game
- **File**: `cookie_cats.csv`
- **90,189 rows × 5 columns**
- **Key columns**:
  - `userid`: Unique player ID
  - `version`: Test group (`gate_30` or `gate_40`)
  - `sum_gamerounds`: Rounds played in first 14 days
  - `retention_1`: Returned on day 1 (boolean)
  - `retention_7`: Returned on day 7 (boolean)

---

## Analysis Workflows

### Fast Food Campaign
1. Data Exploration
2. Visualization: Sales trends by market size, promotion, and time
3. Statistical Testing:
   - ANOVA, Levene’s Test
   - Tukey HSD, Bootstrapping
4. Findings:
   - Promotion 3 had the highest sales, but not significantly better than Promotion 1
   - Promotion 2 was statistically inferior
   - Younger stores and medium-sized markets showed stronger performance

### Cookie Cats Game
1. Data Cleaning & Summary Statistics
2. Visualization: Retention trends and play distribution
3. Statistical Testing:
   - Chi-square tests on retention
   - Confidence Intervals, Bootstrap methods
4. Findings:
   - 1-Day Retention: No significant change between gate_30 and gate_40
   - 7-Day Retention: Significant drop for gate_40 group

---

## Installation & Dependencies

Ensure **Python 3.7+** is installed, then run:

```pip install pandas numpy matplotlib seaborn plotly scipy statsmodels```


### Required Libraries
- pandas – Data handling
- numpy – Numerical operations
- matplotlib, seaborn, plotly – Visualization
- scipy – Statistical tests (ANOVA, Chi-square)
- statsmodels – Confidence intervals, modeling

---

## Project Structure

```
root/
├── fastfoodmarketingcampaign/
│   ├── FastFoodMarketingCampaign.ipynb
│   ├── WA_Marketing-Campaign.csv
│   ├── New_meal_promotion_report.pdf
│   └── README_MARKETING_CAMPAIGN.md
│
├── cookie_cats/
│   ├── cookie_cats.ipynb
│   ├── cookie_cats.csv
│   ├── Cookie_cats_report.pdf
│   └── README_GAME_IMPROVEMENT.md
```

---

## Limitations

### Fast Food Campaign
- Limited to 4-week sales data
- Possible confounders (traffic, demographics) not included

### Cookie Cats Game
- Focused only on 1 and 7-day retention
- Does not account for monetization or in-game progress

---

## Recommendations

### Fast Food Campaign
- Avoid Promotion 2
- Choose Promotion 1 or 3 based on cost-effectiveness and logistics

### Cookie Cats Game
- Keep gate at level 30 for better retention
- Further analyze churn and long-term engagement
- Extend metrics beyond 7 days
