# Cookie Cats A/B Test - Gate Placement & Player Retention

## Overview 
This analysis investigates whether moving the first progression gate in a mobile game (`Cookie Cats`) from **level 30 to level 40** affect player retention. The dataset includes user-level engagement and retention data from a controlled A/B test.

---

## Objective

To evaluate the **impact of gate placement** (level 30 vs level 40) on:

- 1-Day Retention
- 7-Day Retention

---

## Dataset Description

- **File Name:** `cookie_cats.csv`
- **Rows:** 90,189
- **Columns:** 5
- **Key Columns**:
  - `userid`: Unique player ID
  - `version`: Test group (`gate_30` or `gate_40`)
  - `sum_gamerounds`: Total game rounds played in first 14 days
  - `retention_1`: Returned on day 1 (boolean)
  - `retention_7`: Returned on day 7 (boolean)

---

## Project Structure

```
cookie_cats/
├── cookie_cats.ipynb
├── cookie_cats.csv
├── README_GAME_IMPROVEMENT.md
├── Cookie_cats_report.pdf
```

---

## Installation & Dependencies
To run this notebook locally, make sure you have **Python 3.7 or above** installed.

### Required Packages

Install the necessary libraries with the following command:

```pip install pandas numpy matplotlib seaborn plotly scipy statsmodels```

### Dependencies

1. pandas – Dataset handling
2. numpy – Numeric computations and bootstrapping
3. matplotlib – Visualization
4. seaborn – Enhanced data visualization
5. plotly – Interactive plots
6. scipy – Chi-square tests and statistical methods
7. statsmodels – Confidence intervals and proportion testing

---

## Analysis Workflow 

1. **Initial Exploration**:
   - Checked for nulls, duplicates, outliers
   - Summary statistics and distribution analysis
2. **Retention Analysis**:
   - Plotted retention rates and group sizes
   - Visualised round distributions and engagement trends
3. **Statistical Testing**:
   - Performed **Chi-square test** on retention by group
   - Calculated **confidence intervals** and **bootstrap Ci** for differences
4. **Findings**:
   - **1-day retention**: No significant difference between gate_30 and gate_40.
   - **7-day retention**: Crucial drop in gate_40 group, suggesting that moving the gate discouraged long-term play.

---

## Limitations

- Large number of **game round outliers**
- Only considers **1 and 7-day retention**
- Does not track **in-game progression**, **monetization**, or **long-term engagement**

---

## Recommendation

- Retain **gate at level 30** to support long-term retention
- Analyze **player churn** and **progression behaviour** near the gate
- Consider extending retention metrics beyond 7 days





