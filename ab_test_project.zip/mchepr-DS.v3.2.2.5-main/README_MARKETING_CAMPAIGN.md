# Fast Food Marketing Campaign Analysis

## Overview

This project evaluates the effectiveness of three distinct promotional strategies used by a fast-food chain to launch a new menu item. By conducting A/B test over a four-week period and analyzing weekly sales across different store locations and market sizes, the objective is to identify the **most impactful marketing campaign**.

---

## Objective

To **determine which of the three marketing campaigns** (Promotion 1,2, or 3) led to the **highest weekly salaries** of the new menu item using exploratory data analysis and statistical testing.

---

## Project Structure

```
fastfoodmarketingcampaign/
├── FastFoodMarketingCampaign.ipynb
├── WA_Marketing-Campaign.csv
├── README_MARKETING_CAMPAIGN.md
├── New_meal_promotion_report.pdf
```

---

## Installation & Dependencies

To run this project locally, ensure that you have **Python 3.7 or later** installed.

### Required Packages

Install all required dependencies using `pip`:

```pip install pandas numpy matplotlib seaborn plotly scipy statsmodels```

### Dependencies
1. pandas – Data loading and manipulation
2. numpy – Numerical operations
3. matplotlib – Static visualizations
4. seaborn – Statistical visualizations
5. plotly – Interactive charts
6. scipy – Statistical testing (e.g., ANOVA, Levene’s test)
7. statsmodels – Power analysis, statistical modeling

---

## Dataset Description

- **File Name:** `WA_Marketing-Campaign.csv`
- **Rows:** 548
- **Columns:** 7 (plus 1 added column `Promotion_type`)
- **Key Columns:**
  - `MarketID`: Unique identifier for each market
  - `MarketSize`: Categorical variable (Small, Medium, Large)
  - `LocationID`: Store identifier
  - `AgeOfStore`: Store age in years
  - `Promotion`: Marketing campaign type (1, 2, or 3)
  - `week`: Week number (1-4)
  - `SalesInThousands`: Weekly sales (in thousands of units)

---

## Analysis Workflow

1. **Data Exploration**: Summary stats, outlier detection, and feature overview
2. **Visualisation**: Sales distribution, market breadkdowns, weekly trends, and correlation matrices
3. **A/B**:
   - Checked assumptions: independence, normality, equal comparisons
   - Conducted **ANOVA test** to compare means
   - **Tukey HSD** and **Confidence Intervals** for pairwise comparisons
   - Applied **bootstrap methods** to validate results
4. **Findings**:
   - Promotion 2 performed **significantly worse**.
   - Promotion 1 and 3 performed **similarly** well.
   - **Younger stores** and **medium-sized markets** had higher sales.

---

## Key Takeaways

- **Promotion 3** had the highest sales but was **not significantly bettwer** than Promotion 1.
- **Promotion2** was **statistically inferior** and should be avoided.
- Strategic recommendation depends on **cost-effiency, logistics, and business goals** beyond just revenue impact.

---

## Limitations

- **Presence of outliers** affecting distribution.
- Only a **4-week timeframe** for sales tracking.
- Potential **confounders** such as store traffic, demgraphics, or seasonal effects were not included.

---

## Potential Improvements

- Extend data collection beyond 4 weeks.
- Include **promotional costs**, **customer demographics**, and **store traffic data**.
- Explore customer segmentation and day/time trends for further insights.
  



