# **Calculator Project**


## *Overview*:

This project is a command-line calculator built in Python, featuring basic arithmetic operations, nth root calculation, and error handling. The calculator supports the following operations:


- Addition
- Subtraction
- Multiplication
- Division
- Nth Root Calculation
- Updating the value to zero


The calculator maintains a "stored value" which gets updated with each operation. Moreover, the calculator allows user to perform chained operations and resets the stored value back to zero.
Also, there is a visual representation of the calculator.


### *Features*:

1. **Addition**: Adds a number to the stored value.
2. **Subtraction**: Subtracts a number from the stored value.
3. **Multiplication**: Multiplies the stored value by a number.
4. **Division**: Divides the stored value by a number (with error handling for division by zero).
5. **Nth Root**: Calculates the nth root of the stored value, with error handling for invalid operations (such as taking even roots of negative numbers).
6. **Reset**: Resets the stored value back to zero.


### *Installation*:

To use this program, user is required to clone or download the repository, and install any dependencies required (like pytest for testing).


##### *Requirements*:

Python 3.x

pytest (for testing)

Rich library(for visualisation)


### *To Install*:

1. Clone the Repository or Download Files:

  ->Clone the repository using Git:

  ```git clone https://github.com/your-username/calculator.git```
  

  ->Or download the ZIP from the repository.

2. Install pytest (optional, for testing purposes): install the pytest testing library:
   
     ```pip install pytest```
   
3. Install Rich library ( for visual representation) : install Rich library:
   
   ``` pip install rich```

4. Install the Package Directly from GitHub: 
   To install the package directly from GitHub using pip:
  
  ```pip install git+https://github.com/your-username/calculator.git```

5. Run the Program:

After installation, user can run the program by executing the calculator.py script:
     ```python calculator.py```


### *How to Use*:

The calculator provides a simple interface for performing calculations.


1. Start the Program: The program will prompt you for an operation with a message.
2. Enter an Operation: You can perform any of the following operations:


   - *Add*: + followed by a number (e.g., +5.5).
   - *Subtract*: - followed by a number (e.g., -2).
   - *Multiply*: * followed by a number (e.g., *3.0).
   - *Divide*: / followed by a number (e.g., /2.0).
   - *Nth Root*: n followed by a number (e.g., n3 for the cube root).
   - *Reset*: r to reset the value back to zero.


3. Continue Calculating:
   
   After each operation, user will be asked to continue or not (yes/no). To exit the program, enter - no, to continue - yes.


Example:
```
Starting the game...
Value: 0.0
add: +
subtract: -
multiply: *
divide: /
take nroot: n
reset: r
example: +15,n2(take square root),/26.1
[calculator table visual here]
Enter an operation: 0.0+15.5
0.0 ➕ 15.5 = 15.5
Do you want to continue? (yes/no): yes
```


### *Operations Details*:

- **Addition**: Increases the stored value by the provided number.
- **Subtraction**: Decreases the stored value by the provided number.
- **Multiplication**: Multiplies the stored value by the provided number.
- **Division**: Divides the stored value by the provided number. If you attempt to divide by zero, the program will raise an error.
- **Nth Root**: Calculates the nth root of the current stored value. If the stored value is negative and the root is even, an error will be raised.
- **Reset**: Resets the stored value back to 0.


### *Error Handling*:

- Division by Zero: If you attempt to divide by zero, the program will raise a ValueError with a message "Cannot divide by zero!".
- Invalid Nth Root Calculation: If you try to compute an even root (like square root) of a negative number, the program will raise a ValueError with a message "Cannot take a root of a negative number!".


### *Testing*:

Unit tests for the calculator class are provided using the pytest library. To run the tests, user is recommended to use the following command:
```pytest```


The tests ensure the proper functionality of all calculator operations, including:
1. Initial value check
2. Basic operations (add, subtract, multiply, divide)
3. Error handling (division by zero, invalid nth root calculation)
4. Chain operations
5. Reset functionality
   

#### *Sample Tests*:

- test_calculator_initialisation: Verifies a default value
- test_add: Ensures addition works as intended.
- test_subtract: Verifies subtraction works in a correct way.
- test_multiply: Ensures multiplication works correctly.
- test_divide: Verifies division works precisely, including error handling for division by zero.
- test_nroot1 and test_nroot2 and test_nroot3: Make sure nth root calculation, including error handling for invalid roots.
- test_reset: Verifies the reset functionality works as expected.
- test_chain_operations1 and test_chain_operations1: Ensure all the operations are working appropriately.


#### *Contributing*:

If you'd like to contribute to the project, please fork the repository, make your changes, and submit a pull request. If you encounter any bugs or have feature suggestions, feel free to open an issue.
