import re
from rich.console import Console
from rich.table import Table

MATH_EMOJI = {
    "+": "➕",
    "-": "➖",
    "*": "✖️",
    "/": "➗",
    "n": "√",
}
ACTIONS = {
    "add": "+",
    "subtract": "-",
    "multiply": "*",
    "divide": "/",
    "take nroot": "n",
    "reset": "r",
    "example": "+15,n2(take square root),/26.1",
}


class Calculator:
    """
    Initializes a Calculator instance with a default value.

    :param default_value: The initial value of the calculator.
    :type default_value: float
    :raise TypeError: If the default_value is not a float prints a warning message.
    :return: None
    :rtype: None

    """

    def __init__(self, default_value: float = 0.0):
        if not isinstance(default_value, float):
            raise TypeError("Invalid initial value")
        else:
            self.default_value = default_value

    def add(self, value):
        """
        self.default_value gets incremented by the value entered by user.

        :param value: a value entered by user
        :type: float
        :return: None
        :rtype: None

        """
        self.default_value += value

    def subtract(self, value):
        """
        self.default_value is to be decremented by the value entered by user.

        :param value: a float entered by user
        :type: float
        :return: None
        :rtype: None

        """
        self.default_value -= value

    def multiply(self, value):
        """
        self.default_value gets multiplied by the value entered by user.

        :param value: a value entered by user
        :type: float
        :return: None
        :rtype: None

        """
        self.default_value *= value

    def divide(self, value):
        """
        self.default_value is to be divided by the value entered by user if not zero.

        :param value: a value entered by user
        :raise ValueError: if user enters 0 as a value and prints a warning message
        :type: float
        :return: None
        :rtype: None

        """
        if value == 0:
            raise ValueError("Cannot divide by zero!")
        else:
            self.default_value /= value

    def nroot(self, value):
        """
        Computes the nth root of self.default_value.

        :param value: The degree of the root to calculate.
        :type value: float
        :raise ValueError: If self.default_value is negative and the root is even. Prints a warning message.
        :return: None
        :rtype: None

        """
        if self.default_value < 0 and value % 2 == 0:
            raise ValueError("Cannot take an even root of a negative number!")
        elif self.default_value < 0 and value % 2 != 0:
            self.default_value = round(-pow(abs(self.default_value), 1 / value), 10)
        else:
            self.default_value = round(pow(self.default_value, 1 / value), 10)

    def reset(self):
        """
        Sets self.default_value to zero.

        :return: None
        :rtype: None

        """
        self.default_value = 0

    def __float__(self):
        """
        Returns self.default_value as a float.

        :return: returns current value of Calculator instance
        :rtype: float

        """
        return self.default_value

    def __repr__(self):
        """
        Returns a str represantion of a current value of Calculator object.

        :return: a string representation of self.default_value
        :rtype: str

        """
        return f"{self.default_value}"


def main():
    """
    Prints to the screen a welcoming message, stored value and gives user options of actions of what to do
    and displays an image of a calculator.

    The game continues until user stops the game by entering "no".
    Game ends with a message "Game is done!".

    """
    # Create a Calculator instance
    calculator = Calculator()

    print("Starting the game...")
    game_is_on = "yes"

    while game_is_on != "no":

        print("Value:", calculator.default_value)

        # to illustrate possible operations
        for action, symbol in ACTIONS.items():
            print(f"{action}: {symbol}")

        calculator_image()
        print(validation(calculator))
        game_is_on = continue_calculating()

    print("Game is done!")


def validation(calculator) -> str:
    """
    Accepts a str of user and checks whether str is valid and if yes returns a str of the whole performed action.

    :param calculator: An istance of Calculator class
    :type: Calculator
    :return: returns a str
    :rtype: str
    """
    while True:

        operation = input(f"Enter an operation: {calculator.default_value}").strip()
        valid = re.match(r"^([\+\-\*\/nr])(\s*)?(\-?\d+(\.\d+)?)?$", operation)

        # if operation matches the pattern it returns match object otherwise None
        final_expression = is_operation_valid(calculator, valid)

        if final_expression:
            return final_expression
        else:
            print("Entered expression does not match any of operations listed above!")
            continue


def is_operation_valid(calculator, valid):
    """
    if action is valid returns a str of performed action or "Value is set to zero"(if user decides to reset calculator) if not returns False.

    :param calculator: An istance of Calculator class
    :type: Calculator
    :param valid: A match object from the regex validation of the input
    :type: re.match or None
    :return: a str or False
    :rtype: str or bool
    """

    if valid:
        # if user has entered '+','-','*', etc..
        action = valid.group(1)

        # checks whether there is a value after the action
        is_zero = is_value_set_to_zero(valid)

        if not is_zero:
            entered_value = valid.group(3)
            entered_value = float(entered_value)

            # create a whole expression
            expression = creating_expression(calculator, action, entered_value)

        else:
            if action == "r":
                calculator.reset()
                return "Value is set to zero!"

        return expression

    else:
        return False


def is_value_set_to_zero(valid) -> bool:
    """
    Checks is valid.group(3) (a value after a mathematical symbol) exists and returns a bool.

    :param valid: a match object from regex validation input
    :type: re.match or None
    :return: returns a bool
    :rtype: bool
    """
    if valid.group(3):
        is_zero = False
    else:
        is_zero = True
    return is_zero


def creating_expression(calculator, action, entered_value) -> str:
    """
    Checks the action and returns a str relying on action type (e.g., 15.0/3.0 = 5.0).

    :param calculator: An instance of Calculator class
    :type: Calculator
    :param action: The operation to perform, such as '+' for addition or '*' for multiplication, etc...
    :type: str
    :param entered_value: a float entered by user to perform an action
    :type: float
    :return: returns a str
    :rtype: str
    """
    if action != "n":
        expression = (
            str(calculator.default_value)
            + " "
            + MATH_EMOJI[str(action)]
            + " "
            + str(entered_value)
        )
    else:
        expression = MATH_EMOJI[str(action)] + str(calculator.default_value)

    # performs an operation and updates stored value
    matching_actions(calculator, entered_value, action)

    # completes an expression
    expression = expression + " = " + str(calculator)

    return expression


def matching_actions(calculator, entered_value, action) -> None:
    """
    Matches the action entered by user, performs a mathematical operation and updates stored value.

    :param calculator: an object of Calculator class
    :type: Calculator
    :param entered_value: a float entered by user to perform an action
    :type: float
    :param action: The operation to perform, such as '+' for addition or '*' for multiplication, etc...
    :type: str
    :return: None

    """
    match action:
        case "+":
            calculator.add(entered_value)
        case "-":
            calculator.subtract(entered_value)
        case "*":
            calculator.multiply(entered_value)
        case "/":
            calculator.divide(entered_value)
        case "n":
            calculator.nroot(entered_value)


def continue_calculating() -> str:
    """
    Decided whether user wants to continue using calculator or not.

    :raise ValueError: if a str is not "yes" or "no"
    :return: a str of "yes" or "no"
    :rtype: str

    """
    while True:
        game_is_on = input("Do you want to continue? (yes/no) ").strip().lower()

        if game_is_on == "yes" or game_is_on == "no":
            return game_is_on
        else:
            print("Incorrect input. Please enter 'yes' or 'no'!")


def calculator_image() -> None:
    """
    Prints the calculator image.

    :return: None
    :rtype: None
    """

    # create a console instance
    console = Console()

    # create a Rich table
    table = Table(title="Calculator", show_lines=True)

    # add columns
    table.add_column(justify="center")
    table.add_column(justify="center")
    table.add_column(justify="center")
    table.add_column(justify="center")

    # add rows
    table.add_row("7", "8", "9", "+")
    table.add_row("4", "5", "6", "-")
    table.add_row("1", "2", "3", "*")
    table.add_row("0", ".", "=", "/")

    # print the table
    console.print(table)


if __name__ == "__main__":
    main()
