import pytest
from calculator import Calculator


def test_calculator_initialisation():
    calculator = Calculator(0.0)
    assert calculator.default_value == 0.0


def test_add():
    calculator = Calculator(0.0)
    calculator.add(14.5)
    calculator.add(0.5)
    assert calculator.default_value == 15.0


def test_subtract():
    calculator = Calculator(-28.0)
    calculator.subtract(-2.0)
    assert calculator.default_value == -26.0


def test_multiply():
    calculator = Calculator(-11.1)
    calculator.multiply(3.0)
    assert calculator.default_value == -33.3


def test_divide1():
    calculator = Calculator(-50.5)
    calculator.divide(-5.0)
    assert calculator.default_value == 10.1


def test_divide2():
    calculator = Calculator(-50.1739)

    with pytest.raises(ValueError):
        calculator.divide(0.0)


def test_nroot1():
    calculator = Calculator(81.0)
    calculator.nroot(4.0)
    assert calculator.default_value == 3.0


def test_nroot2():
    calculator = Calculator(-125.0)
    calculator.nroot(3.0)
    assert calculator.default_value == -5.0


def test_nroot3():
    calculator = Calculator(-625.0)
    with pytest.raises(ValueError):
        calculator.nroot(2.0)


def test_reset():
    calculator = Calculator(288.19)
    calculator.reset()
    assert calculator.default_value == 0.0


def test_chain_operations1():
    calculator = Calculator(-27.1)
    calculator.add(-0.9)
    calculator.divide(2.0)
    assert calculator.default_value == -14.0


def test_chain_operations2():
    calculator = Calculator(0.0)
    calculator.reset()
    calculator.add(150.6)
    calculator.multiply(0.5)
    calculator.add(-11.3)
    calculator.nroot(3.0)
    assert calculator.default_value == 4.0
