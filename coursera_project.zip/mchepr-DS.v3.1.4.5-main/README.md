
# Coursera Dataset Analysis

This project analyzes data from the Coursera course dataset. The goal is to explore course characteristics, understand enrollment patterns, and identify factors influencing course popularity.

## Project Overview

This analysis focuses on the Coursera course dataset, using Python libraries such as **Pandas**, **Matplotlib**, **Seaborn**. The primary objectives are:

- Perform exploratory data analysis (EDA) on the dataset.
- Visualize key trends and patterns in course offerings.
- Analyze the relationship between course ratings, enrollments, and other attributes.
- Provide actionable insights and recommendations for future improvements.

## Project Structure

```
Coursera-EDA/
├── coursera.ipynb        # Jupyter Notebook with the complete analysis
└── coursera_data.csv     # Dataset used for the analysis
```

## Objectives

1. Load and clean the Coursera dataset.
2. Explore the relationship between course characteristics (e.g., difficulty level, certification type) and popularity.
3. Visualize patterns using appropriate plots and statistical summaries.
4. Identify insights from the data and provide recommendations for platform improvements.
5. Ensure the code is well-structured, efficient, and follows best practices.

## Analysis Workflow

1. **Data Collection**: Load the dataset using Pandas.
2. **Data Cleaning**: Handle missing values and standardize data formats.
3. **Exploratory Data Analysis (EDA)**:
   - Analyze course distribution by difficulty and certification type.
   - Examine the relationship between course ratings and enrollments.
   - Identify trends in course language offerings.
4. **Visualization**: Use Matplotlib, Seaborn, Plotly to create meaningful plots.
5. **Insights & Recommendations**: Summarize findings and suggest improvements.

## Key Insights

1. **Strong Educational Network**: With content from 154 organizations, Coursera offers a diverse learning experience, reflecting its global reach and strong academic and industry partnerships.  

2. **Language Accessibility Gap**: English dominates as the primary language of instruction, indicating a need for more multilingual courses to improve accessibility for non-English speakers.  

3. **Certification Focus**: Course Certificates are the most common, suggesting that learners prioritize flexible, shorter-term credentials over specialized or professional certifications.  

4. **High Program Quality**: The platform maintains **high learner satisfaction**, as reflected by an average course rating of **4.67**.  

5. **Beginner-Friendly Approach**: The majority of courses target beginner-level learners, aligning with a focus on accessible education for a broad audience.  

6. **Enrollment Patterns**: Mixed-level courses attract the most students, while advanced-level courses see lower engagement, highlighting a preference for more accessible and flexible learning paths.  

7. **Course Difficulty Impact**: Higher difficulty correlates with lower enrollments, indicating that learners are more inclined toward courses that are easier to complete.  

8. **Popularity Drives Ratings**: Popular courses tend to receive higher ratings, suggesting that widely enrolled courses generally meet learner expectations.  

9. **Trending Subjects**: Programming, Korean language, business, and COVID-19-related content are the most in-demand topics, reflecting both industry needs and societal interests.
 

## How to Run the Project

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/TuringCollegeSubmissions/mchepr-DS.v3.1.4.5
   ```
   
## Dependencies

Ensure the following packages are installed:

- pandas
- numpy
- matplotlib
- seaborn
- langdetect
- plotly
- cufflinks
  
## Future Improvements

1. Analyze course completion rates and student success to better assess the real impact of courses.

2. Incorporate pricing and financial aid data to evaluate course affordability and accessibility.

3. Link courses to job placement and industry demand to identify those with the highest career value.

4. Use qualitative feedback from student reviews to provide deeper insights into course quality.



