
# DS.v3.2.1.5  
# Mental Health in Tech: Data-Driven Answers for a Healthier Workplace

**Can we build a workplace culture where mental health is not just tolerated, but actively protected?**

This project seeks to answer that—using real-world data to uncover where the tech industry stands on mental health and how it can do better.

---

## Why This Matters

Mental health remains underreported, stigmatized, and poorly integrated into workplace culture—especially in the fast-paced tech industry. Yet its impact on productivity, retention, and employee well-being is undeniable.

This project explores how mental health is experienced across tech roles and demographics, and how open discussion and supportive policy can reshape workplace norms.

---

## Project Overview

Using a survey dataset from Open Source Mental Illness (OSMI) stored in SQLite format, this analysis explores mental health prevalence, risk factors, and disclosure impacts in professional settings. The data is processed and visualized using:

- SQL  
- Pandas  
- Seaborn  
- Matplotlib  

### Main Objectives

- Highlight the scale and structure of mental health issues in tech.
- Understand the impact of job role, remote work, and demographics.
- Assess how disclosure affects workplace relationships.
- Evaluate how supportive (or not) employers are.
- Inform empathetic, evidence-based workplace policies.

---

## Project Structure

```
mental-health-analysis/
├── mental_health.ipynb   # Jupyter Notebook with full analysis
├── mental_health.sqlite  # Original dataset in SQLite format
└── README.md             # Project overview and documentation
```

---

## Analysis Workflow

1. Data Collection  
   - Use SQL to join and query relevant tables from the SQLite database.

2. Data Cleaning  
   - Normalize responses, handle missing values, and restructure the data.

3. Exploratory Data Analysis (EDA)  
   - Analyze distributions of age, gender, country, occupation,etc .

4. Prevalence & Confidence Intervals  
   - Estimate disorder prevalence (e.g., anxiety, ADHD) and compute 95% confidence intervals using Wilson scores.

5. Interpretation & Reporting  
   - Discuss trends, bias, and actionable insights.

---

## Key Insights

### 1. Widespread Challenges in Tech
Mental health struggles are concentrated in high-demand roles:  
Back-end (51%), Front-end (10%), Designers (8%), Team leads (6%).

### 2. Remote Work and Isolation
Remote and partially remote workers reported more mental health issues:  
Partially remote: 53%, Fully remote: 24%

### 3. Top Diagnosed Conditions
Most common mental health issues:  
Anxiety (319), Depression (114), ADHD (56)

### 4. Family History as a Risk Factor
27% reported a family history of mental illness—strongly associated with personal struggles.

### 5. Disclosure Rarely Changes Relationships
93% said disclosing a condition did not affect workplace relationships.

### 6. Employer Support Still Lacking
61% rated employer response as poor or unclear.  
37% reported no available mental health resources.

### 7. Biased Sample
73% of respondents were male.  
Responses were concentrated in the USA, UK, and Canada.

### 8. Mental Health Is Systemic
Trends show mental health issues are not isolated but systemic and structural—and therefore actionable.

---

## Final Takeaway

**Can we build a workplace culture where mental health is not just tolerated, but actively protected?**

Yes—but only if we act on the data.

This analysis reveals that mental health issues in tech are widespread, patterned, and linked to specific work and demographic conditions. Despite this, employers often fail to provide resources or support.

To move forward, workplaces must:
- Make mental health a core part of organizational culture.
- Encourage open, stigma-free conversations.
- Provide accessible, structured mental health resources.
- Use data to track change and impact over time.

---

## How to Run This Project

### 1. Install Dependencies

```pip install pandas numpy matplotlib seaborn sqlite3 scipy statsmodels```

### 2. Run the Notebook

```jupyter notebook mental_health.ipynb```

---

## Dependencies

- pandas  
- numpy  
- matplotlib  
- seaborn  
- scipy  
- statsmodels  
- sqlite3 (built-in with Python)

---

## Future Improvements

1. Expand Sample Size  
   Improve representation across gender, roles, and global regions.

2. Enhance Data Quality  
   Clean inconsistent responses and handle missing values more rigorously.

3. Add Key Variables  
   Include measures of work stress, access to care, and social support.

---
