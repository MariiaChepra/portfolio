# DS.v3.1.3.5
# Spotify Top 50 Tracks of 2020 - Data Analysis

## Project Overview
This project dives into the Spotify Top 50 Tracks of 2020 dataset to uncover the key elements that define a chart-topping hit. By analyzing popular artists, dominant genres, and standout albums, along with audio features like danceability, loudness, and acousticness, this study provides insights into what makes a song resonate with listeners worldwide.

## Dataset
- Source: Spotify Top 50 Tracks of 2020
- Format: CSV
- Features Include:
  - Track name, Artist, Genre, Album
  - Danceability, Energy, Loudness, Acousticness, Speechiness
  - Duration, Valence, Tempo, and more

## Data Processing
### 1. Data Cleaning
- Handling missing values
- Removing duplicate rows
- Removing unnecessary features
- Treating outliers (IQR method, visualization)

### 2. Exploratory Data Analysis (EDA)
- Dataset overview (size, features, data types)
- Identifying categorical & numerical features
- Checking for duplicate entries/unneccessary features and removing them
- Identifying most frequent artists, albums, and genres
- Analyzing track durations (longest & shortest songs)

### 3. Audio Feature Analysis
- Danceability: Identifying tracks with high (>0.7) and low (<0.4) scores
- Loudness: Filtering tracks with extreme values (above -5 and below -8)

### 4. Correlation Analysis
- Feature Correlation: Heatmap visualization of relationships between features
- Identifying strongly positive, negative, and weakly/non correlated attributes

### 5. Genre-Based Comparisons
- Danceability, Loudness, and Acousticness across and between Pop, Hip-Hop/Rap, Dance/Electronic, and Alternative/Indie
- Using data projection for better insights

## Key Insights
- Most Popular Artists: Dua Lipa, Billie Eilish, Travis Scott
- Total Unique Artists: 40
- Total Unique Albums: 45
- Most Popular Genre: Pop
- Some albums had more than one hit, indicating their dominance on the charts.
- Hip-Hop/Rap and Dance/Electronic had the highest danceability, while Alternative/Indie scored the lowest.
- Hip-Hop/Rap and Pop were the loudest, whereas Alternative/Indie tracks were quieter and more acoustic.
- Acousticness was highest in Alternative/Indie and lowest in Hip-Hop/Rap and Dance/Electronic.
- The longest track was "SICKO MODE" by Travis Scott, while the shortest was "Mood (feat. iann dior)" by 24kGoldn.
- Strongest Positive Correlation: energy-loudness
- Strongest Negative Correlation: None

## How to Improve This Analysis
- Add more visualizations (pairplots, scatterplots for trends)
- Separate genres into subcategories
- Expand dataset for year-over-year comparisons

## Getting Started
### Prerequisites
- Python 3.x
- Pandas, NumPy, Matplotlib, Seaborn

### Run the Project
1. Clone the repository:
   
   ```git clone https://github.com/TuringCollegeSubmissions/mchepr-DS.v3.1.3.5```
   
2. Install dependencies (for data projection):
   
   ```pip install pandas numpy matplotlib seaborn```
   
3. Run the Jupyter Notebook:
   
   ```jupyter notebook Spotify_analysis.ipynb```


